package edu.unomaha.burger.bun;
import edu.unomaha.pizza.AbstractMenuItem;

public abstract class BurgerBun extends AbstractMenuItem {
    @Override
    public abstract String toString();
}