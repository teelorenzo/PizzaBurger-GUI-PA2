package edu.unomaha.burger.garnish;
import edu.unomaha.pizza.AbstractMenuItem;

public abstract class BurgerGarnish extends AbstractMenuItem {
    @Override
    public abstract String toString();
}