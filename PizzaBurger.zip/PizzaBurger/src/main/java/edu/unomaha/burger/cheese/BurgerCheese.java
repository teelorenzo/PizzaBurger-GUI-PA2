package edu.unomaha.burger.cheese;
import edu.unomaha.pizza.AbstractMenuItem;

public abstract class BurgerCheese extends AbstractMenuItem {
    @Override
    public abstract String toString();
}