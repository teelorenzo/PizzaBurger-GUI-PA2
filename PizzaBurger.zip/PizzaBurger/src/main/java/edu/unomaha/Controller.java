package edu.unomaha;

import edu.unomaha.burger.*;
import edu.unomaha.burger.bun.*;
import edu.unomaha.burger.cheese.*;
import edu.unomaha.burger.garnish.*;
import edu.unomaha.burger.patty.*;


import edu.unomaha.pizza.*;
import edu.unomaha.pizza.crust.*;
import edu.unomaha.pizza.sauce.*;
import edu.unomaha.pizza.topping.*;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;

import java.util.ArrayList;
import java.util.List;

public class Controller {

    // UI Elements
    @FXML private ComboBox<PizzaCrust> pizzaCrustBox;
    @FXML private ComboBox<PizzaSauce> pizzaSauceBox;
    @FXML private ListView<PizzaTopping> pizzaToppingList;

    @FXML private ComboBox<BurgerBun> burgerBunBox;
    @FXML private ListView<BurgerPatty> burgerPattyList;
    @FXML private ListView<BurgerCheese> burgerCheeseList;
    @FXML private ListView<BurgerGarnish> burgerGarnishList;

    @FXML private VBox orderDisplayBox;
    @FXML private Label subtotalLabel;
    @FXML private Label totalLabel;

    // Order storage
    private final List<AbstractMenuItem> orderItems = new ArrayList<>();

    @FXML
    private void initialize() {
        initializePizzaOptions();
        initializeBurgerOptions();
        updateTotals();
    }

    private void initializePizzaOptions() {
        pizzaCrustBox.getItems().addAll(new ThinCrust(), new ThickCrust());
        pizzaSauceBox.getItems().addAll(new TomatoSauce(), new AlfredoSauce());

        pizzaToppingList.getItems().addAll(
                new PepperoniTopping(), new SausageTopping(), new MushroomTopping(),
                new MozzarellaTopping(), new AsiagoTopping(), new PepperTopping()
        );
        pizzaToppingList.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
    }

    private void initializeBurgerOptions() {
        burgerBunBox.getItems().addAll(new SesameBun());
        burgerPattyList.getItems().addAll(new BeefPatty());
        burgerCheeseList.getItems().addAll(new CheddarCheese());
        burgerGarnishList.getItems().addAll(new Lettuce());

        burgerPattyList.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
        burgerCheeseList.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
        burgerGarnishList.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
    }

    @FXML
    private void handleAddPizza() {
        Pizza pizza = new Pizza();
        pizza.setCrust(pizzaCrustBox.getValue());
        pizza.setSauce(pizzaSauceBox.getValue());

        List<PizzaTopping> selectedToppings = pizzaToppingList.getSelectionModel().getSelectedItems();
        selectedToppings.stream()
                .limit(4)
                .forEach(pizza::addTopping);

        addItemToOrder(pizza);
    }

    @FXML
    private void handleAddBurger() {
        Burger burger = new Burger();
        burger.setBun(burgerBunBox.getValue());

        burgerPattyList.getSelectionModel().getSelectedItems().stream()
                .limit(4)
                .forEach(burger::addPatty);

        burgerCheeseList.getSelectionModel().getSelectedItems().stream()
                .limit(4)
                .forEach(burger::addCheese);

        burgerGarnishList.getSelectionModel().getSelectedItems().stream()
                .limit(4)
                .forEach(burger::addGarnish);

        addItemToOrder(burger);
    }

    private void addItemToOrder(AbstractMenuItem item) {
        if (item == null) return;

        orderItems.add(item);
        Label itemLabel = new Label(String.format("%s - $%.2f", item.toNiceString(), item.getPrice()));
        orderDisplayBox.getChildren().add(itemLabel);

        updateTotals();
    }

    @FXML
    private void handleViewReceipt() {
        orderItems.sort((a, b) -> Double.compare(a.getPrice(), b.getPrice()));

        StringBuilder receipt = new StringBuilder();
        double total = 0.0;

        for (AbstractMenuItem item : orderItems) {
            receipt.append(String.format("%s - $%.2f%n", item.toNiceString(), item.getPrice()));
            total += item.getPrice();
        }

        receipt.append(String.format("%nTotal: $%.2f", total));

        Alert receiptAlert = new Alert(Alert.AlertType.INFORMATION);
        receiptAlert.setTitle("Receipt");
        receiptAlert.setHeaderText("Your Order Summary");
        receiptAlert.setContentText(receipt.toString());
        receiptAlert.showAndWait();
    }

    private void updateTotals() {
        double total = orderItems.stream()
                .mapToDouble(AbstractMenuItem::getPrice)
                .sum();

        subtotalLabel.setText(String.format("Subtotal: $%.2f", total));
        totalLabel.setText(String.format("Total: $%.2f", total));
    }
}
