package edu.unomaha.pizza.sauce;
public class AlfredoSauce extends PizzaSauce {
	@Override
	public String toString() {
		return "Alfredo Sauce";
	}
}
