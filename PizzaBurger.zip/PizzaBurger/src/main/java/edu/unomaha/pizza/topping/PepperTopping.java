package edu.unomaha.pizza.topping;
public class PepperTopping extends VeggieTopping {
	public String toString() {
		return "Pepper Topping";
	}
}
