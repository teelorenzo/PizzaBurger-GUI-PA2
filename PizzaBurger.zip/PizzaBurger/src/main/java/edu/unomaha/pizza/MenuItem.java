package edu.unomaha.pizza;
public interface MenuItem {
    public String toNiceString();
    public Double getPrice();
}