package edu.unomaha.pizza.crust;
public class ThinCrust extends PizzaCrust {
	@Override
	public String toString() {
		return "Thin Crust";
	}
}
