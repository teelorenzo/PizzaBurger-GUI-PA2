package edu.unomaha.pizza.topping;
public class AsiagoTopping extends CheeseTopping {
	public String toString() {
		return "Asiago Topping";
	}
}
