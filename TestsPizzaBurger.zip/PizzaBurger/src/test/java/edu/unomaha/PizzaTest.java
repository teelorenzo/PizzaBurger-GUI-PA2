package edu.unomaha;

import static org.junit.jupiter.api.Assertions.*;

import edu.unomaha.pizza.Pizza;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import edu.unomaha.pizza.crust.ThinCrust;
import edu.unomaha.pizza.sauce.TomatoSauce;
import edu.unomaha.pizza.topping.PepperoniTopping;
import edu.unomaha.pizza.Order;
import edu.unomaha.burger.Burger;
import edu.unomaha.burger.bun.BurgerBun;

/**
 * Test class for Pizza functionality.
 */
public class PizzaTest {
    private Pizza pizza;
    private ThinCrust crust;
    private TomatoSauce sauce;
    private PepperoniTopping pepperoni;
    private Burger burger;
    private static final double DELTA = 0.001; // Delta for floating-point comparisons
    private Order order;

    @BeforeEach
    void setUp() {
        pizza = new Pizza();
        crust = new ThinCrust();
        sauce = new TomatoSauce();
        pepperoni = new PepperoniTopping();
        burger = new Burger(new BurgerBun() {
            @Override
            public String toNiceString() {
                return "";
            }

            @Override
            public Double getPrice() {
                return 0.0;
            }

            @Override
            public String toString() {
                return "";
            }
        });
        order = new Order();  // Assuming there's an Order class to handle total price.
    }

    /**
     * Test that the total price of a pizza is increased by the right amount when a topping is added.
     */
    @Test
    void testPizzaPriceIncreaseWithTopping() {
        pizza.setCrust(crust);
        pizza.setSauce(sauce);
        double priceBeforeTopping = pizza.getPrice();

        pizza.addTopping(pepperoni);
        double priceAfterTopping = pizza.getPrice();

        assertEquals(pepperoni.getPrice(), priceAfterTopping - priceBeforeTopping, DELTA,
                "Pizza price should increase by exactly the topping price");
    }

    /**
     * Test that the total price of a pizza matches the sum of its crust, sauce and toppings.
     */
    @Test
    void testPizzaTotalPriceMatchesComponentSum() {
        pizza.setCrust(crust);
        pizza.setSauce(sauce);
        pizza.addTopping(pepperoni);

        double expectedTotal = crust.getPrice() + sauce.getPrice() + pepperoni.getPrice();
        assertEquals(expectedTotal, pizza.getPrice(), DELTA,
                "Pizza total price should equal sum of components");
    }

    /**
     * Test that the total price of the order is increased by the right amount after assembling a pizza.
     */
    @Test
    void testOrderPriceIncreaseWithPizza() {
        pizza.setCrust(crust);
        pizza.setSauce(sauce);
        pizza.addTopping(pepperoni);

        double orderPriceBefore = order.getTotalPrice();
        order.addItem(pizza);

        double orderPriceAfter = order.getTotalPrice();
        assertEquals(pizza.getPrice(), orderPriceAfter - orderPriceBefore, DELTA,
                "Order price should increase by the pizza price");
    }

    /**
     * Test that the total price of the order is increased by the right amount after assembling a burger.
     */
    @Test
    void testOrderPriceIncreaseWithBurger() {
        double orderPriceBefore = order.getTotalPrice();
        order.addItem(burger);

        double orderPriceAfter = order.getTotalPrice();
        assertEquals(burger.getPrice(), orderPriceAfter - orderPriceBefore, DELTA,
                "Order price should increase by the burger price");
    }

    /**
     * Test that the total price of the order is increased by the right amount after assembling two pizzas.
     */
    @Test
    void testOrderPriceIncreaseWithTwoPizzas() {
        pizza.setCrust(crust);
        pizza.setSauce(sauce);
        pizza.addTopping(pepperoni);

        double orderPriceBefore = order.getTotalPrice();
        order.addItem(pizza);
        order.addItem(pizza);  // Adding two pizzas

        double orderPriceAfter = order.getTotalPrice();
        assertEquals(2 * pizza.getPrice(), orderPriceAfter - orderPriceBefore, DELTA,
                "Order price should increase by the price of two pizzas");
    }
}
