package edu.unomaha.burger.patty;
import edu.unomaha.pizza.AbstractMenuItem;

public abstract class BurgerPatty extends AbstractMenuItem {
    @Override
    public abstract String toString();
}