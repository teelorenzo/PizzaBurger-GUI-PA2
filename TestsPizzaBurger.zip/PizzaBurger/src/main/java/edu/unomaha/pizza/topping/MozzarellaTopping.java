package edu.unomaha.pizza.topping;
public class MozzarellaTopping extends CheeseTopping {
	public String toString() {
		return "Mozzarella Topping";
	}
}
