package edu.unomaha.pizza.topping;
public class MushroomTopping extends VeggieTopping {
	public String toString() {
		return "Mushroom Topping";
	}
}
