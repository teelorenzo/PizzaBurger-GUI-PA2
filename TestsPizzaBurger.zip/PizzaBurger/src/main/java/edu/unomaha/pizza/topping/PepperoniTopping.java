package edu.unomaha.pizza.topping;
public class PepperoniTopping extends MeatTopping {
	public String toString() {
		return "Pepperoni Topping";
	}
}
