package edu.unomaha.pizza;

import edu.unomaha.pizza.Pizza;
import edu.unomaha.burger.Burger;
import java.util.ArrayList;
import java.util.List;

/**
 * Order class to manage multiple items (pizza, burger) and calculate total price.
 */
public class Order {
    private List<Object> items; // List to hold pizza, burger, etc.
    private double totalPrice;

    public Order() {
        items = new ArrayList<>();
        totalPrice = 0.0;
    }

    /**
     * Adds an item (pizza or burger) to the order.
     */
    public void addItem(Object item) {
        items.add(item);
        if (item instanceof Pizza) {
            totalPrice += ((Pizza) item).getPrice();
        } else if (item instanceof Burger) {
            totalPrice += ((Burger) item).getPrice();
        }
    }

    /**
     * Gets the total price of the order.
     */
    public double getTotalPrice() {
        return totalPrice;
    }
}
