package edu.unomaha;

public class App {
    public int add(int a, int b) {
        return a + b;
    }
}